

```python
# Import dependencies 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import sem
import numpy as np
```


```python
clinical_trial_df = 'raw_data/clinicaltrial_data.csv'
clinical_trial_df = pd.read_csv(clinical_trial_df)
```


```python
mouse_drug_df = 'raw_data/mouse_drug_data.csv'
mouse_drug_df = pd.read_csv(mouse_drug_df)
```


```python
clinical_mouseDrug_df = pd.merge(clinical_trial_df, mouse_drug_df, on = 'Mouse ID')
clinical_mouseDrug_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>1</th>
      <td>b128</td>
      <td>5</td>
      <td>45.651331</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>2</th>
      <td>b128</td>
      <td>10</td>
      <td>43.270852</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>3</th>
      <td>b128</td>
      <td>15</td>
      <td>43.784893</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>4</th>
      <td>b128</td>
      <td>20</td>
      <td>42.731552</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
  </tbody>
</table>
</div>




```python
drug = ['Capomulin', 'Infubinol', 'Ketapril', 'Placebo']
mouse_drugResponse_df = clinical_mouseDrug_df.loc[clinical_mouseDrug_df['Drug'].isin(drug)]
mouse_drugResponse_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>1</th>
      <td>b128</td>
      <td>5</td>
      <td>45.651331</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>2</th>
      <td>b128</td>
      <td>10</td>
      <td>43.270852</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>3</th>
      <td>b128</td>
      <td>15</td>
      <td>43.784893</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>4</th>
      <td>b128</td>
      <td>20</td>
      <td>42.731552</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
  </tbody>
</table>
</div>




```python
tumorVolume_df = pd.DataFrame(mouse_drugResponse_df.groupby(['Drug', 'Timepoint'])['Tumor Volume (mm3)'].mean())
tumorVolume_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
    </tr>
  </tbody>
</table>
</div>




```python
tumorVolume_df.reset_index(inplace=True)
tumorVolume_pivot_df = tumorVolume_df.pivot(index='Timepoint', columns = 'Drug', values ='Tumor Volume (mm3)')
tumor_response_df = pd.DataFrame(tumorVolume_pivot_df.to_records())
tumor_response_df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>44.266086</td>
      <td>47.062001</td>
      <td>47.389175</td>
      <td>47.125589</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>43.084291</td>
      <td>49.403909</td>
      <td>49.582269</td>
      <td>49.423329</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>42.064317</td>
      <td>51.296397</td>
      <td>52.399974</td>
      <td>51.359742</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>40.716325</td>
      <td>53.197691</td>
      <td>54.920935</td>
      <td>54.364417</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
      <td>39.939528</td>
      <td>55.715252</td>
      <td>57.678982</td>
      <td>57.482574</td>
    </tr>
    <tr>
      <th>6</th>
      <td>30</td>
      <td>38.769339</td>
      <td>58.299397</td>
      <td>60.994507</td>
      <td>59.809063</td>
    </tr>
    <tr>
      <th>7</th>
      <td>35</td>
      <td>37.816839</td>
      <td>60.742461</td>
      <td>63.371686</td>
      <td>62.420615</td>
    </tr>
    <tr>
      <th>8</th>
      <td>40</td>
      <td>36.958001</td>
      <td>63.162824</td>
      <td>66.068580</td>
      <td>65.052675</td>
    </tr>
    <tr>
      <th>9</th>
      <td>45</td>
      <td>36.236114</td>
      <td>65.755562</td>
      <td>70.662958</td>
      <td>68.084082</td>
    </tr>
  </tbody>
</table>
</div>




```python
tumor_response_melt = tumor_response_df.melt('Timepoint', var_name='Drug',  value_name='Tumer Volume (mm3)')
tumor_response_melt.shape
```




    (40, 3)




```python
# Scatter plot for tumor volume over treatment 
sns.set_style("white")

sns.pointplot(x="Timepoint", y="Tumer Volume (mm3)", hue='Drug', size=5, aspect=1.5, scale = .8,
               markers=['o', 'v', 's', '|']*100,linestyles = "dashed", legend=False, data=tumor_response_melt)

# Set title
plt.title('Tumor response to treatment', weight='bold').set_fontsize('15')

# Set x-axis label
plt.xlabel('Time (days)', weight= 'bold').set_fontsize('12')

# Set y-axis label
plt.ylabel('Tumor Volume (mm3)', weight='bold').set_fontsize('12')

plt.grid()
plt.legend(loc='best')
plt.show()
```


![png](output_8_0.png)



```python
tumorVolume_error = pd.DataFrame(mouse_drugResponse_df.groupby(['Drug', 'Timepoint'])['Tumor Volume (mm3)'].sem())
tumorVolume_error.reset_index(inplace=True)
tumorVolume_error_pivot = tumorVolume_error.pivot(index='Timepoint', columns = 'Drug', values ='Tumor Volume (mm3)')
tumorVolume_error_pivot
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.448593</td>
      <td>0.235102</td>
      <td>0.264819</td>
      <td>0.218091</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.702684</td>
      <td>0.282346</td>
      <td>0.357421</td>
      <td>0.402064</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.838617</td>
      <td>0.357705</td>
      <td>0.580268</td>
      <td>0.614461</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.909731</td>
      <td>0.476210</td>
      <td>0.726484</td>
      <td>0.839609</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.881642</td>
      <td>0.550315</td>
      <td>0.755413</td>
      <td>1.034872</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.934460</td>
      <td>0.631061</td>
      <td>0.934121</td>
      <td>1.218231</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1.052241</td>
      <td>0.984155</td>
      <td>1.127867</td>
      <td>1.287481</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.223608</td>
      <td>1.055220</td>
      <td>1.158449</td>
      <td>1.370634</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1.223977</td>
      <td>1.144427</td>
      <td>1.453186</td>
      <td>1.351726</td>
    </tr>
  </tbody>
</table>
</div>




```python
tumorVolume_error_pivot = pd.DataFrame(tumorVolume_error_pivot.to_records())
tumorVolume_error_melt = tumorVolume_error_pivot.melt('Timepoint', var_name='Drug',  value_name='Standard Errors')
tumorVolume_error_melt.shape
```




    (40, 3)




```python
tumor_response_df = pd.merge(tumor_response_melt, tumorVolume_error_melt, on =("Timepoint", "Drug"))
tumor_response_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>Tumer Volume (mm3)</th>
      <th>Standard Errors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Capomulin</td>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>Capomulin</td>
      <td>44.266086</td>
      <td>0.448593</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>Capomulin</td>
      <td>43.084291</td>
      <td>0.702684</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>Capomulin</td>
      <td>42.064317</td>
      <td>0.838617</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>Capomulin</td>
      <td>40.716325</td>
      <td>0.909731</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Error bar for tumor volumes 

plt.errorbar('Timepoint', 'Tumer Volume (mm3)', yerr='Standard Errors', data = tumor_response_df, color='g',
             fmt ='|', ecolor='blue', capsize=4, elinewidth=3, markersize=10, 
             linestyle='dashed', linewidth=1)

plt.title('Tumor volume with standard errors', weight='bold').set_fontsize('15')

# Set x-axis label
plt.xlabel('Time (days)', weight= 'bold').set_fontsize('12')

# Set y-axis label
plt.ylabel('Tumor Volume (mm3)', weight='bold').set_fontsize('12')

plt.grid()
plt.show()
```


![png](output_12_0.png)



```python
metastatic_df = pd.DataFrame(mouse_drugResponse_df.groupby(['Drug', 'Timepoint'])['Metastatic Sites'].mean())
metastatic_df.reset_index(inplace=True)
metastatic_pivot_df = metastatic_df.pivot(index='Timepoint', columns = 'Drug', values ='Metastatic Sites')
metastatic_sites_df = pd.DataFrame(metastatic_pivot_df.to_records())
metastatic_sites_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>0.160000</td>
      <td>0.280000</td>
      <td>0.304348</td>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>0.320000</td>
      <td>0.666667</td>
      <td>0.590909</td>
      <td>0.833333</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>0.375000</td>
      <td>0.904762</td>
      <td>0.842105</td>
      <td>1.250000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>0.652174</td>
      <td>1.050000</td>
      <td>1.210526</td>
      <td>1.526316</td>
    </tr>
  </tbody>
</table>
</div>




```python
metastatic_sites_melt = metastatic_sites_df.melt('Timepoint', var_name='Drug',  value_name='Metastatic Sites')
metastatic_sites_melt.shape
```




    (40, 3)




```python
# Scatter plot for metastatic sites over time 

sns.set_style("white", {'grid.linestyle': '--'})

sns.pointplot(x="Timepoint", y="Metastatic Sites", hue='Drug', markers=['o', 'v', 's', '^']*100, 
               size =5, aspect=1.5, scale = .8, gridsize =15, linestyles = "dashed", legend=False,
               data=metastatic_sites_melt)

# Set title
plt.title('Changes in Metastatic Sites', weight='bold').set_fontsize('15')

# Set x-axis label
plt.xlabel('Time (days)', weight='bold').set_fontsize('12')

# Set y-axis label
plt.ylabel('Metastatic Sites', weight='bold').set_fontsize('12')

plt.grid()
plt.legend(loc='best')
plt.show()
```


![png](output_15_0.png)



```python
metastatic_error = pd.DataFrame(mouse_drugResponse_df.groupby(['Drug', 'Timepoint'])['Metastatic Sites'].sem())
metastatic_error.reset_index(inplace=True)
metastatic_error_pivot = metastatic_error.pivot(index='Timepoint', columns = 'Drug', values ='Metastatic Sites')
metastatic_error_pivot
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.074833</td>
      <td>0.091652</td>
      <td>0.098100</td>
      <td>0.100947</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.125433</td>
      <td>0.159364</td>
      <td>0.142018</td>
      <td>0.115261</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.132048</td>
      <td>0.194015</td>
      <td>0.191381</td>
      <td>0.190221</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.161621</td>
      <td>0.234801</td>
      <td>0.236680</td>
      <td>0.234064</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.181818</td>
      <td>0.265753</td>
      <td>0.288275</td>
      <td>0.263888</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.172944</td>
      <td>0.227823</td>
      <td>0.347467</td>
      <td>0.300264</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.169496</td>
      <td>0.224733</td>
      <td>0.361418</td>
      <td>0.341412</td>
    </tr>
    <tr>
      <th>40</th>
      <td>0.175610</td>
      <td>0.314466</td>
      <td>0.315725</td>
      <td>0.297294</td>
    </tr>
    <tr>
      <th>45</th>
      <td>0.202591</td>
      <td>0.309320</td>
      <td>0.278722</td>
      <td>0.304240</td>
    </tr>
  </tbody>
</table>
</div>




```python
metastatic_error_pivot = pd.DataFrame(metastatic_error_pivot.to_records())
metastatic_error_melt = metastatic_error_pivot.melt('Timepoint', var_name='Drug',  value_name='Standard Errors')
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>Standard Errors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>index</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>index</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>index</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>index</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>index</td>
      <td>4.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
metastatic_sites_df = pd.merge(metastatic_sites_melt, metastatic_error_melt, on =("Timepoint", "Drug"))
metastatic_sites_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>Metastatic Sites</th>
      <th>Standard Errors</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Capomulin</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>Capomulin</td>
      <td>0.160000</td>
      <td>0.074833</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>Capomulin</td>
      <td>0.320000</td>
      <td>0.125433</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>Capomulin</td>
      <td>0.375000</td>
      <td>0.132048</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>Capomulin</td>
      <td>0.652174</td>
      <td>0.161621</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot error bar for metastatic sites 
plt.errorbar('Timepoint', 'Metastatic Sites', yerr='Standard Errors', data = metastatic_sites_df, color='g',
             fmt ='|', ecolor='blue', capsize=4, elinewidth=3, markersize=10, 
             linestyle='dashed', linewidth=1)

plt.title('Metastatic sites with standard errors', weight='bold').set_fontsize('15')

# Set x-axis label
plt.xlabel('Time (days)', weight= 'bold').set_fontsize('12')

# Set y-axis label
plt.ylabel('Metastatic sites', weight='bold').set_fontsize('12')

plt.grid()
plt.show()
```


![png](output_19_0.png)



```python
# Compute survival counts at different time points for different treatment 
mice_survival_df = pd.DataFrame(mouse_drugResponse_df.groupby(['Drug', 'Timepoint'])['Mouse ID'].count())
mice_survival_df.rename(columns={'Mouse ID': 'Mouse Count'}, inplace=True)
```


```python
mice_survival_df.reset_index(inplace=True)
mice_survival_pivot_df = mice_survival_df.pivot(index='Timepoint', columns = 'Drug', values ='Mouse Count')
```


```python
mice_survival_count_df = pd.DataFrame(mice_survival_pivot_df.to_records())
mice_survival_count_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>25</td>
      <td>25</td>
      <td>23</td>
      <td>24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>25</td>
      <td>21</td>
      <td>22</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>24</td>
      <td>21</td>
      <td>19</td>
      <td>20</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>23</td>
      <td>20</td>
      <td>19</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Compute survival rate 
index = np.arange(0,10,1)
columns = ['Timepoint', 'Capomulin', 'Infubinol', 'Ketapril', 'Placebo']
survival_rate_df = pd.DataFrame(index=index, columns=columns)
survival_rate_df['Timepoint'] = mice_survival_count_df['Timepoint']
survival_rate_df['Capomulin'] = mice_survival_count_df['Capomulin']*100/25
survival_rate_df['Infubinol'] = mice_survival_count_df['Infubinol']*100/25
survival_rate_df['Ketapril'] = mice_survival_count_df['Ketapril']*100/25
survival_rate_df['Placebo'] = mice_survival_count_df['Placebo']*100/25
survival_rate_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Capomulin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Placebo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>96.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>100.0</td>
      <td>84.0</td>
      <td>88.0</td>
      <td>96.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>96.0</td>
      <td>84.0</td>
      <td>76.0</td>
      <td>80.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>92.0</td>
      <td>80.0</td>
      <td>76.0</td>
      <td>76.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
survival_rate_melt = survival_rate_df.melt('Timepoint', var_name='Drug',  value_name='Survival Rate (%)')
```


```python
# Plot for survival rate during treatment 

sns.set_style("white",{'grid.linestyle': '--'})

g = sns.pointplot(x="Timepoint", y="Survival Rate (%)", hue='Drug', linestyles = "dashed", gridsize=15, 
                  markers=['o', 'v', 's', '^']*100, scale = 1,legend=False, data=survival_rate_melt)

# Set title
plt.title('Survival During Treatment', weight='bold').set_fontsize('15')

# Set x-axis label
plt.xlabel('Time (days)', weight='bold').set_fontsize('12')

# Set y-axis label
plt.ylabel('Survival Rate (%)', weight='bold').set_fontsize('12')

plt.grid()
plt.legend(loc='best')
g.set(alpha =0.7)
plt.show()
```


![png](output_25_0.png)



```python
# Compute total % volume change in tumor over 45 day treatment 
# Tumor volume at day 45
val_45 = pd.DataFrame(tumor_response_df[tumor_response_df.Timepoint==45]['Tumer Volume (mm3)'])

# Tumor volume at day one
val_0 = pd.DataFrame(tumor_response_df[tumor_response_df.Timepoint==0]['Tumer Volume (mm3)'])

val_45['Drug'] = ['Capomulin', 'Infubinol', 'Ketapril', 'Placebo']
val_0['Drug'] = ['Capomulin', 'Infubinol', 'Ketapril', 'Placebo']

# Merge two dataframes 
val = pd.merge(val_0, val_45, on ='Drug')
val.rename(columns = {'Tumer Volume (mm3)_x': 'Tumer_day1', 'Tumer Volume (mm3)_y': 'Tumer_day45'}, inplace=True)
# computing the percent change 
val['total_per_change'] = round((val['Tumer_day45']-val['Tumer_day1'])*100/val['Tumer_day1'],2)
per_vol_change = val.loc[:, ('Drug', 'total_per_change')]
per_vol_change
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>total_per_change</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Capomulin</td>
      <td>-19.48</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Infubinol</td>
      <td>46.12</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ketapril</td>
      <td>57.03</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Placebo</td>
      <td>51.30</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Bar chart for total % change in tumor volume over 45 day treatment

treatment = per_vol_change['Drug']
bars_treatment = per_vol_change['total_per_change']
x_axis = np.arange(len(bars_treatment))
tick_locations = [value for value in x_axis]

ax = per_vol_change.plot(kind='bar', width= 1, legend=False, color='r', edgecolor='black')
                        
ax.set_ylim(-20, 60)
for i, label in enumerate(list(per_vol_change.index)):
    total_per_change = per_vol_change.loc[label]['total_per_change']
    ax.annotate(str(total_per_change), (i, total_per_change + 0.2))

plt.xticks(tick_locations, drug)
plt.title('Tumer Change over 45 Day Treatment', weight='bold').set_fontsize('15')

plt.ylabel('% Tumer Volume Change', weight='bold').set_fontsize('12')
plt.grid()
plt.show()
```


![png](output_27_0.png)

